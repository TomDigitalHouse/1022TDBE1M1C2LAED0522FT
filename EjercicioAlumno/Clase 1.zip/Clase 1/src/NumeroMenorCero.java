public class NumeroMenorCero extends Exception{

}
